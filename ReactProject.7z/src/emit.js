const EventEmitter = require('events').EventEmitter;
const emit = new EventEmitter();
export { emit };