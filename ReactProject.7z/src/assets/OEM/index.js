// 注：修改公司名称与标题时，请记得修改public文件夹下index.html文件内的title
const OEM = {
    Title: '冬笋云', //公司标题,
    MiniTitle: '冬', // 左侧导航栏缩小后的文字,
    Icon: '', // 公司favicon图标,  如要修改favicon.icon图标，直接替换public文件夹下的favicon.ico即可
    Logo: '', // 公司logo,
    Companies: '冬笋科技' // 公司名称
    // Dashboard: 'Dashboard',
    // Mygates: '我的网关',
    // Myapp: '我的应用',
    // Appstore: '应用商店',
    // GatewayDetails: '网关详情',
    // AppDetails: '应用信息',
    // Appsettings: '应用设置',
    // Createnewapp: '创建新应用',
    // InstallApp: '安装应用',
    // CodeEdit: '代码编辑',
    // TemplateDetails: '模板详情',
    // UserInfo: '用户信息',
    // AccessAuthorizationCode: '访问授权码',
    // VirtualGateways: '虚拟网关',
    // Sharegroup: '共享组管理',
    // Member: '成员管理',
    // Platformevent: '平台消息',
    // Gatewayevents: '设备消息',
    // Browsinghistory: '设备数据 · 历史浏览'
}
export default OEM;